# Changelog

## 1.0.0

### Added
- Structured task records and task listing.
- Safe `sync` command for fetch + remote collaboration discovery.
- Local HTML dashboard generated from validated collaboration records.
- Collaboration audit for missing independent reviews and recorded blockers.

### Retained from v0.3
- Provider-neutral AI Agent Bridge.
- Mock agent workflow without paid APIs.
- Remote event validation, status, review, synthesis, test evidence, and human-confirmed finalization.

### Compatibility
- The collaboration protocol remains `0.1` so existing v0.x event and member records remain readable.
