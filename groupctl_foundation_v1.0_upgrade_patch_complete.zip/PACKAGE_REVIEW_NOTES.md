# groupctl 1.0 package review

This package is a local, file-backed collaboration product designed to work with Git repositories.

## Included capabilities

- Collaboration event protocol and validation.
- Remote event discovery and synchronization.
- Task coordination.
- Provider-neutral AI context export and structured agent submission.
- Review, integration, test evidence, blockers, and synthesis records.
- Status, audit, and local HTML dashboard.
- Human-confirmed finalization.
- Mock agent and three-member simulation.

## Not claimed

The package does not include a hosted server, user authentication service, billing, or a built-in commercial LLM. External AI providers are intentionally decoupled from the collaboration protocol.
