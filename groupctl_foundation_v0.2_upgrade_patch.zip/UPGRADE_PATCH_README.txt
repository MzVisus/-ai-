groupctl_foundation v0.2 — Upgrade patch
========================================

Purpose
-------
Apply the v0.2 status and synthesis improvements to an existing clone of
`groupctl_foundation` while preserving that clone's `.git` history and `.group`
project data.

Important
---------
- This patch intentionally does NOT include `.group/`, `.git/`, credentials,
  or local configuration.
- Do not apply it over uncommitted work.
- Do not force-push or overwrite `main`.
- Apply it on a new working branch based on your current collaboration branch.

Suggested PowerShell procedure
-------------------------------
1. Open PowerShell in your existing local `groupctl_foundation` clone.
2. Check for local changes:

   git status --short

   Commit or safely stash any changes before continuing.

3. Fetch and create a new branch from the collaboration branch you already use:

   git fetch origin
   git switch main
   git pull --ff-only origin main
   git switch -c feature/groupctl-v0.2-synthesis-status

   The previous `people/P17/pub-sync` pull request is already merged. Start from
   the updated `main` branch unless you have deliberately chosen another base.
   Do not overwrite uncommitted work.

4. Extract this patch ZIP into the repository root and allow it to overwrite
   the listed source/documentation files. It will not touch `.group/`.

5. Run verification:

   python -m unittest discover -s tests -v
   python groupctl.py validate
   python scripts/run_three_member_demo.py --auto-confirm-final

6. Review the diff before committing:

   git diff --check
   git status --short
   git diff

7. Commit only after reviewing the changes:

   git add groupctl.py README.md AGENT_INSTRUCTIONS.md QUICKSTART_WINDOWS.md CHANGELOG.md examples/synthesis_candidate_payload.json scripts/run_three_member_demo.py specifications/03_event_format_contract.md specifications/04_command_reference.md tests/test_groupctl.py
   git commit -m "feat: add synthesis proposals and group status"

8. Push your feature branch and open/update a pull request. Do not merge to the
   canonical branch until the normal review and test process is complete.

What v0.2 adds
--------------
- `groupctl status` for published changes, review/integration state, test
  evidence, synthesis proposals, blockers, and finalization state.
- `groupctl status --remote origin` to include already-fetched remote events.
- `synthesis_candidate` structured events and the `SYNTHESIZE <topic>` AI
  collaboration procedure.
- A three-clone local Git demo that exercises publication, discovery, review,
  integration, conflict resolution, test evidence, synthesis recording, and
  finalization.

Compatibility note
------------------
The group protocol envelope remains at 0.1. The new `synthesis_candidate`
 event type is understood by v0.2 clients; older clients may reject it as an
unsupported event type. Update all participating clones before using synthesis
candidate events in a shared group.
